@echo off
setlocal EnableExtensions
chcp 65001 >nul
title MoonPad™ Installer - Moonlit™
color 0B
cls

echo   ============================================================
echo     MoonPad™  -  a Moonlit™ product
echo     Founded by melthedev (mel)
echo     Moonlit™ and all related names and marks are trademarks.
echo   ============================================================
echo.
echo   This installs MoonPad™ for Adobe After Effects.
echo   No admin rights needed. Close this window to cancel.
echo.
pause

set "SRC=%~dp0moonpad"
set "DEST=%APPDATA%\Adobe\CEP\extensions"

echo.
echo   [1/4] Checking files...
if not exist "%SRC%\CSXS\manifest.xml" (
  echo.
  echo   [X] Can't find the "moonpad" folder next to install.bat.
  echo       Unzip the whole download first, then run install.bat again.
  echo.
  pause
  exit /b 1
)

echo   [2/4] Allowing MoonPad™ to load in After Effects...
for %%V in (9 10 11 12 13) do reg add "HKCU\Software\Adobe\CSXS.%%V" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1

tasklist /FI "IMAGENAME eq AfterFX.exe" 2>nul | find /I "AfterFX.exe" >nul
if not errorlevel 1 (
  echo.
  echo   [!] After Effects is open. Let this finish, then close and reopen it.
  echo.
)

echo   [3/4] Installing...
if not exist "%DEST%" mkdir "%DEST%"
if exist "%DEST%\moonpad" rmdir /S /Q "%DEST%\moonpad"
if exist "%DEST%\ae-notepad" rmdir /S /Q "%DEST%\ae-notepad"
xcopy "%SRC%" "%DEST%\moonpad\" /E /I /Y /Q >nul
if errorlevel 1 (
  echo.
  echo   [X] Copy failed. Close After Effects and run install.bat again.
  echo.
  pause
  exit /b 1
)

echo   [4/4] Verifying...
if not exist "%DEST%\moonpad\CSXS\manifest.xml" (
  echo.
  echo   [X] Could not verify the install. Run install.bat again.
  echo.
  pause
  exit /b 1
)

echo.
echo   ============================================================
echo     [OK] MoonPad™ is installed!
echo.
echo     To open it:
echo       1. Restart After Effects
echo       2. Go to  Window ^> Extensions ^> MoonPad
echo.
echo     Your pads are saved in  Documents\MoonPad
echo.
echo     MoonPad™ by Moonlit™  -  Founded by melthedev (mel)
echo   ============================================================
echo.
pause
endlocal
exit /b 0
