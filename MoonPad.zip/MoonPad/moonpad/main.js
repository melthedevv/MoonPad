(function () {
  var $ = function (id) { return document.getElementById(id); };
  var board = $('board'), world = $('world'), wl = $('wiresCol'), wlI = $('wlI'), wlC = $('wlC'), tmp = $('tmp');
  var wgs = document.querySelectorAll('.wg');
  var COLORS = ['', '#2f6fb3', '#3f9b5a', '#b3562f', '#8a4fb3', '#b39a2f']; // '' = theme default header
  var HEAD = 30;
  var WIRE_COLORS = [['Red', '#e5484d'], ['Orange', '#f5841f'], ['Yellow', '#f5c518'], ['Green', '#30a46c'], ['Teal', '#12a594'],
                     ['Blue', '#3e8ef7'], ['Purple', '#8e4ec6'], ['Pink', '#e93d82'], ['White', '#f2f2f2'], ['Gray', '#8b8d98']];
  var WIRE_HEX = WIRE_COLORS.map(function (c) { return c[1]; });

  // ================= storage =================
  var fs = null, path = null, DIR = null;
  try {
    fs = require('fs'); path = require('path');
    DIR = path.join(require('os').homedir(), '.ae-notepad');
    if (!fs.existsSync(DIR)) fs.mkdirSync(DIR);
  } catch (e) { fs = null; }

  function rd(name) {
    try {
      if (fs) { var f = path.join(DIR, name); return fs.existsSync(f) ? fs.readFileSync(f, 'utf8') : null; }
      return localStorage.getItem('moonpad-' + name);
    } catch (e) { return null; }
  }
  function wr(name, s) {
    try { if (fs) fs.writeFileSync(path.join(DIR, name), s); else localStorage.setItem('moonpad-' + name, s); } catch (e) {}
  }
  function rdJSON(name) { var r = rd(name); if (!r) return null; try { return JSON.parse(r); } catch (e) { return null; } }

  // ================= pads (.mnpad files) =================
  var PADS = null, MAPF = null, curFile = null, curProject = null, padCreated = Date.now();
  var st = { nextId: 1 }, nodes = [], links = [], v = { x: 40, y: 40, z: 1 };
  var MEDIA = null, MAXVID = 200 * 1024 * 1024, EXPORT_CAP = 150 * 1024 * 1024;
  var MEDIAOK = /^[a-f0-9]{40}\.(mp4|webm|mov|m4v|ogv)$/;
  var DATAVIDHEAD = /^data:video\/(mp4|webm|ogg|quicktime|x-m4v);base64$/;
  var VEXT = { mp4: 'mp4', m4v: 'm4v', mov: 'mov', webm: 'webm', ogv: 'ogv', ogg: 'ogv' };
  var VMIME = { mp4: 'video/mp4', m4v: 'video/x-m4v', mov: 'video/quicktime', webm: 'video/webm', ogv: 'video/ogg' };
  var MIME2EXT = { 'video/mp4': 'mp4', 'video/x-m4v': 'm4v', 'video/quicktime': 'mov', 'video/webm': 'webm', 'video/ogg': 'ogv' };
  var DATAIMG = /^data:image\/(png|jpe?g|gif|webp|bmp|svg\+xml);base64,[A-Za-z0-9+\/=]+$/;

  function documentsDir() {
    try {
      if (window.__adobe_cep__ && window.__adobe_cep__.getSystemPath) {
        var p = window.__adobe_cep__.getSystemPath('myDocuments');
        if (p) {
          p = decodeURI(String(p).replace(/^file:\/\//, ''));
          if (/^\/[A-Za-z]:/.test(p)) p = p.slice(1);
          if (p) return path.normalize(p);
        }
      }
    } catch (e) {}
    return path.join(require('os').homedir(), 'Documents');
  }
  function writeAtomic(f, s) { var t = f + '.tmp'; fs.writeFileSync(t, s); fs.renameSync(t, f); }
  function readJSONFile(f) { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) { return null; } }
  if (fs) {
    try {
      PADS = path.join(documentsDir(), 'MoonPad');
      if (!fs.existsSync(PADS)) fs.mkdirSync(PADS);
      MAPF = path.join(PADS, 'projects.json');
      MEDIA = path.join(PADS, 'media');
      if (!fs.existsSync(MEDIA)) fs.mkdirSync(MEDIA);
    } catch (e) { PADS = null; }
  }
  var map = (PADS && readJSONFile(MAPF)) || { version: 1, projects: {} };
  if (!map.projects) map.projects = {};
  function saveMap() { if (PADS) { try { writeAtomic(MAPF, JSON.stringify(map, null, 2)); } catch (e) {} } }

  function keyOf(p) { return (p || '').replace(/\\/g, '/').toLowerCase() || '__untitled__'; }
  function baseOf(p) {
    var b = p ? path.basename(p.replace(/\\/g, '/')) : 'Untitled';
    return b.replace(/\.(aep|aepx)$/i, '') || 'Untitled';
  }
  function safeName(n) { return (String(n).replace(/\.mnpad$/i, '').replace(/[\\\/:*?"<>|]/g, '_').trim() || 'Pad') + '.mnpad'; }
  function sameDir(a, b) {
    var x = path.resolve(a), y = path.resolve(b);
    if (process.platform !== 'linux') { x = x.toLowerCase(); y = y.toLowerCase(); }
    return x === y;
  }
  function uniqueName(name) {
    var base = safeName(name).replace(/\.mnpad$/i, ''), n = base, i = 2, used = {};
    for (var k in map.projects) if (map.projects[k] && map.projects[k].file) used[map.projects[k].file.toLowerCase()] = 1;
    while (fs.existsSync(path.join(PADS, n + '.mnpad')) || used[(n + '.mnpad').toLowerCase()]) n = base + ' (' + (i++) + ')';
    return n + '.mnpad';
  }
  function padFileFor(projPath) {
    var k = keyOf(projPath), e = map.projects[k];
    if (e && e.file) return path.join(PADS, e.file);
    var name = uniqueName(baseOf(projPath));
    map.projects[k] = { file: name, project: projPath || '' };
    saveMap();
    return path.join(PADS, name);
  }

  // Imported .mnpad files are untrusted: clean everything before it touches the DOM.
  var ALLOW = { B: 1, I: 1, U: 1, STRONG: 1, EM: 1, BR: 1, DIV: 1, P: 1, SPAN: 1, UL: 1, OL: 1, LI: 1, SUB: 1, SUP: 1 };
  var DROPTAGS = { SCRIPT: 1, STYLE: 1, IFRAME: 1, OBJECT: 1, EMBED: 1, LINK: 1, META: 1, TEMPLATE: 1, NOSCRIPT: 1, SVG: 1, MATH: 1, FORM: 1, TEXTAREA: 1, SELECT: 1 };
  function cleanHtml(html) {
    var doc = new DOMParser().parseFromString('<body>' + String(html || '') + '</body>', 'text/html');
    var out = document.createElement('div');
    (function walk(src, dst) {
      for (var c = src.firstChild; c; c = c.nextSibling) {
        if (c.nodeType === 3) { dst.appendChild(document.createTextNode(c.nodeValue)); continue; }
        if (c.nodeType !== 1) continue;
        var tag = c.tagName.toUpperCase();
        if (DROPTAGS[tag]) continue;
        if (tag === 'IMG') {
          var s = c.getAttribute('src') || '';
          if (DATAIMG.test(s)) { var im = document.createElement('img'); im.setAttribute('src', s); dst.appendChild(im); }
        } else if (ALLOW[tag]) {
          var e = document.createElement(tag.toLowerCase()); walk(c, e); dst.appendChild(e);
        } else walk(c, dst);
      }
    })(doc.body, out);
    return out.innerHTML;
  }
  function num(x, d, min, max) { x = +x; if (!isFinite(x)) x = d; if (min != null && x < min) x = min; if (max != null && x > max) x = max; return x; }
  function normalizePad(raw) {
    if (!raw || typeof raw !== 'object' || !Array.isArray(raw.nodes)) return null;
    var seen = {}, outN = [], maxId = 0;
    raw.nodes.forEach(function (n) {
      if (!n || typeof n !== 'object') return;
      var id = Math.floor(num(n.id, 0, 0, 1e9));
      if (id < 1 || seen[id]) return;
      var type = n.type === 'image' ? 'image' : (n.type === 'video' ? 'video' : 'text');
      var o = { id: id, type: type, x: num(n.x, 0, -1e6, 1e6), y: num(n.y, 0, -1e6, 1e6),
        w: num(n.w, 240, 120, 4000), h: num(n.h, 140, 60, 4000),
        color: COLORS.indexOf(n.color) > 0 ? n.color : '', html: '', src: '', media: '' };
      if (type === 'text') o.html = cleanHtml(n.html);
      else if (type === 'video') {
        o.media = MEDIAOK.test(String(n.media || '')) ? String(n.media) : '';
        var sv = typeof n.src === 'string' ? n.src : '', ci = sv.indexOf(',');
        o.src = (ci > 0 && ci < 60 && DATAVIDHEAD.test(sv.slice(0, ci).toLowerCase()) && sv.length < 3e8) ? sv : '';
      } else { if (!DATAIMG.test(String(n.src || ''))) return; o.src = n.src; }
      seen[id] = 1; if (id > maxId) maxId = id; outN.push(o);
    });
    var outL = [];
    (Array.isArray(raw.links) ? raw.links : []).forEach(function (l) {
      if (Array.isArray(l) && seen[l[0]] && seen[l[1]] && l[0] !== l[1]) {
        var lk = [+l[0], +l[1]];
        if (WIRE_HEX.indexOf(l[2]) >= 0) lk.push(l[2]); // optional per-link color
        outL.push(lk);
      }
    });
    var rv = raw.view || {};
    return { nodes: outN, links: outL,
      view: { x: num(rv.x, 40, -1e7, 1e7), y: num(rv.y, 40, -1e7, 1e7), z: num(rv.z, 1, 0.2, 2.5) },
      nextId: Math.max(maxId + 1, Math.floor(num(raw.nextId, 1, 1, 1e9))), created: num(raw.created, Date.now()) };
  }
  // ---- video files live in Documents/MoonPad/media (named by content hash) ----
  var crypto = null, Buf = null;
  try { crypto = require('crypto'); Buf = require('buffer').Buffer; } catch (e) {}
  function videoExt(name, mime) {
    if (mime && MIME2EXT[mime]) return MIME2EXT[mime];
    var m = /\.([a-z0-9]+)$/i.exec(name || ''); return m ? (VEXT[m[1].toLowerCase()] || null) : null;
  }
  function mediaUrl(name) {
    var p = path.join(MEDIA, name).replace(/\\/g, '/');
    return 'file://' + (p.charAt(0) === '/' ? '' : '/') + encodeURI(p).replace(/#/g, '%23').replace(/\?/g, '%3F');
  }
  function storeBuffer(buf, ext) {
    var name = crypto.createHash('sha1').update(buf).digest('hex') + '.' + ext, dest = path.join(MEDIA, name);
    if (!fs.existsSync(dest)) { fs.writeFileSync(dest + '.tmp', buf); fs.renameSync(dest + '.tmp', dest); }
    return name;
  }
  function storePath(src, ext, cb) {
    var h = crypto.createHash('sha1'), s = fs.createReadStream(src);
    s.on('data', function (d) { h.update(d); });
    s.on('error', cb);
    s.on('end', function () {
      var name = h.digest('hex') + '.' + ext, dest = path.join(MEDIA, name);
      if (fs.existsSync(dest)) return cb(null, name);
      fs.copyFile(src, dest + '.tmp', function (err) {
        if (err) return cb(err);
        try { fs.renameSync(dest + '.tmp', dest); cb(null, name); } catch (e2) { cb(e2); }
      });
    });
  }
  // videos bundled inside an exported .mnpad (data URLs) are unpacked into the media folder on open/import
  function ingestVideos(pad) {
    pad.nodes.forEach(function (n) {
      if (n.type !== 'video' || !n.src) return;
      try {
        var ci = n.src.indexOf(','), head = n.src.slice(0, ci).toLowerCase();
        var mt = /^data:(video\/[a-z0-9-]+);base64$/.exec(head);
        if (!MEDIA || !crypto || !mt || !MIME2EXT[mt[1]]) throw new Error('bad');
        n.media = storeBuffer(Buf.from(n.src.slice(ci + 1), 'base64'), MIME2EXT[mt[1]]);
      } catch (e) { n.media = ''; }
      n.src = '';
    });
  }
  function blankPad() { return { nodes: [], links: [], view: { x: 40, y: 40, z: 1 }, nextId: 1, created: Date.now() }; }
  function parsePad(text) {
    try { var o = JSON.parse(text); if (o && o.format === 'mnpad') { var pp = normalizePad(o); if (pp) ingestVideos(pp); return pp; } } catch (e) {}
    return null;
  }
  function readPadFile(f) { try { if (fs.existsSync(f)) return parsePad(fs.readFileSync(f, 'utf8')) || normalizePad(readJSONFile(f)); } catch (e) {} return null; }
  function rdLocal() { try { return normalizePad(JSON.parse(localStorage.getItem('moonpad-pad'))); } catch (e) { return null; } }

  // ---- saving ----
  var bTimer = null;
  function padBase() { return curFile ? path.basename(curFile).replace(/\.mnpad$/i, '') : 'MoonPad'; }
  function padObject() {
    return { format: 'mnpad', version: 1, name: padBase(), project: baseOf(curProject), created: padCreated,
      modified: Date.now(), nodes: nodes, links: links, view: v, nextId: st.nextId };
  }
  function setChip(s) {
    var c = $('padchip');
    c.textContent = (curFile ? padBase() + '.mnpad' : 'MoonPad') + (s ? ' · ' + s : '');
    c.title = curFile || '';
  }
  function saveNow() {
    bTimer = null;
    try {
      var s = JSON.stringify(padObject());
      if (fs && curFile) writeAtomic(curFile, s); else localStorage.setItem('moonpad-pad', s);
      setChip('saved ' + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
    } catch (e) { setChip('save failed'); }
  }
  function save() { setChip('saving…'); clearTimeout(bTimer); bTimer = setTimeout(saveNow, 400); }
  function flushSave() { if (bTimer) { clearTimeout(bTimer); saveNow(); } }

  // ---- AE project tracking ----
  function getProject(cb) {
    try {
      if (window.__adobe_cep__ && window.__adobe_cep__.evalScript) {
        window.__adobe_cep__.evalScript('(function(){try{return app.project.file?app.project.file.fsName:""}catch(e){return ""}})()', function (r) {
          cb(r && String(r).indexOf('EvalScript error') < 0 && r !== 'undefined' && r !== 'null' ? String(r) : '');
        });
        return;
      }
    } catch (e) {}
    cb('');
  }
  function clearBoard() {
    for (var id in els) if (els[id].parentNode) els[id].parentNode.removeChild(els[id]);
    els = {}; selId = null; wlI.innerHTML = ''; wlC.innerHTML = '';
  }
  function loadPad(p) {
    clearBoard();
    nodes = p.nodes; links = p.links; v = p.view; st.nextId = p.nextId;
    nodes.forEach(makeNode);
    applyView(); redraw(); updateEmpty();
  }
  function legacyBoard() {
    var f = fs && path.join(DIR, 'board.json');
    return f && fs.existsSync(f) ? { file: f, data: readJSONFile(f) } : null;
  }
  function enterProject(projPath) {
    flushSave();
    var prev = curProject, k = keyOf(projPath);
    curProject = projPath;
    if (!fs || !PADS) { loadPad(rdLocal() || blankPad()); setChip(''); return; }

    // untitled project that was just saved for the first time: keep the board, rename its file
    var u = map.projects.__untitled__;
    if (prev === '' && projPath && !map.projects[k] && u && curFile && path.join(PADS, u.file) === curFile) {
      var nn = uniqueName(baseOf(projPath));
      try { fs.renameSync(curFile, path.join(PADS, nn)); } catch (e) { nn = u.file; }
      map.projects[k] = { file: nn, project: projPath };
      delete map.projects.__untitled__; saveMap();
      curFile = path.join(PADS, nn); save();
      return;
    }

    var f = padFileFor(projPath), pad = readPadFile(f), fresh = false;
    if (!pad) {
      var lg = legacyBoard(); // first run after upgrading: adopt the old single board
      if (lg && (pad = normalizePad(lg.data))) { try { fs.renameSync(lg.file, lg.file + '.migrated'); } catch (e) {} fresh = true; }
      else pad = blankPad();
    }
    curFile = f; padCreated = pad.created || Date.now();
    loadPad(pad);
    if (fresh) saveNow(); else setChip('');
  }

  // ================= settings & themes =================
  var BUILTIN = {
    dark:  { bg: '#1b1c1f', surface: '#232529', node: '#2a2c31', head: '#3a3d44', text: '#e6e7ea', accent: '#5aa0ff', dot: '#34363b', wire: '#9aa0aa' },
    light: { bg: '#f3f4f6', surface: '#ffffff', node: '#ffffff', head: '#e5e7eb', text: '#1f2328', accent: '#2f6feb', dot: '#d4d7dd', wire: '#6b7280' }
  };
  var KEYS = [['bg', 'Board background'], ['surface', 'Toolbar & panels'], ['node', 'Node body'], ['head', 'Node header'],
              ['text', 'Text'], ['accent', 'Accent'], ['dot', 'Grid dots'], ['wire', 'Pins']];
  var FONTS = [['Segoe UI', '"Segoe UI"'], ['System UI', 'system-ui'], ['Arial', 'Arial'], ['Helvetica Neue', '"Helvetica Neue"'],
               ['Verdana', 'Verdana'], ['Tahoma', 'Tahoma'], ['Trebuchet MS', '"Trebuchet MS"'], ['Georgia', 'Georgia'],
               ['Times New Roman', '"Times New Roman"'], ['Consolas', 'Consolas'], ['Courier New', '"Courier New"'], ['Monospace', 'monospace']];
  var S = { mode: 'dark', theme: 'default', font: 'Segoe UI', customFont: '', fontSize: 13, bgImage: '', bgOpacity: 60, custom: [] };
  var saved = rdJSON('settings.json');
  if (saved) for (var k in saved) S[k] = saved[k];

  var sTimer;
  function saveS() { clearTimeout(sTimer); sTimer = setTimeout(function () { wr('settings.json', JSON.stringify(S)); }, 300); }

  function hex2rgb(h) { h = h.replace('#', ''); if (h.length === 3) h = h.replace(/(.)/g, '$1$1'); var n = parseInt(h, 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
  function rgb2hex(a) { return '#' + a.map(function (x) { x = Math.max(0, Math.min(255, Math.round(x))); return (x < 16 ? '0' : '') + x.toString(16); }).join(''); }
  function mix(a, b, t) { var A = hex2rgb(a), B = hex2rgb(b); return rgb2hex([A[0] + (B[0] - A[0]) * t, A[1] + (B[1] - A[1]) * t, A[2] + (B[2] - A[2]) * t]); }
  function lum(h) { var c = hex2rgb(h); return (0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2]) / 255; }

  function findCustom(id) { for (var i = 0; i < S.custom.length; i++) if (S.custom[i].id === id) return S.custom[i]; return null; }
  function curVars() {
    if (S.theme !== 'default') { var t = findCustom(S.theme); if (t) return t.vars; S.theme = 'default'; }
    return BUILTIN[S.mode === 'light' ? 'light' : 'dark'];
  }

  function applyTheme() {
    var t = curVars(), r = document.documentElement.style, dark = lum(t.bg) < 0.5;
    var map = {
      bg: t.bg, surface: t.surface, node: t.node, head: t.head, text: t.text, accent: t.accent, dot: t.dot, wire: t.wire,
      border: mix(t.surface, t.text, 0.16), muted: mix(t.text, t.bg, 0.5),
      btn: mix(t.surface, t.text, 0.07), btnh: mix(t.surface, t.text, 0.15), input: mix(t.surface, t.bg, 0.55),
      shadow: dark ? 'rgba(0,0,0,.5)' : 'rgba(0,0,0,.16)', onaccent: lum(t.accent) > 0.6 ? '#111' : '#fff'
    };
    for (var key in map) r.setProperty('--' + key, map[key]);
    r.setProperty('color-scheme', dark ? 'dark' : 'light');
  }
  function applyBg() {
    $('bgimg').style.backgroundImage = S.bgImage ? 'url("' + S.bgImage + '")' : 'none';
    $('bgimg').style.opacity = S.bgOpacity / 100;
  }
  function applyFont() {
    var f = '"Segoe UI"';
    FONTS.forEach(function (x) { if (x[0] === S.font) f = x[1]; });
    var c = (S.customFont || '').replace(/["';{}<>]/g, '').trim();
    document.body.style.fontFamily = (c ? '"' + c + '", ' : '') + f + ', system-ui, sans-serif';
    document.body.style.fontSize = S.fontSize + 'px';
  }

  // ---- settings UI ----
  var panel = $('settings');
  function openSettings(open) {
    panel.classList.toggle('open', open);
    $('gearBtn').classList.toggle('on', open);
  }
  $('gearBtn').addEventListener('click', function () { openSettings(!panel.classList.contains('open')); });
  $('closeSet').addEventListener('click', function () { openSettings(false); });

  FONTS.forEach(function (f) {
    var o = document.createElement('option'); o.value = f[0]; o.textContent = f[0]; $('fontSel').appendChild(o);
  });

  // color pickers for the theme editor
  KEYS.forEach(function (kv) {
    var row = document.createElement('div'); row.className = 'row';
    row.innerHTML = '<span>' + kv[1] + '</span><input type="color" id="c_' + kv[0] + '">';
    $('pickers').appendChild(row);
    row.querySelector('input').addEventListener('input', function (e) {
      var t = findCustom(S.theme); if (!t) return;
      t.vars[kv[0]] = e.target.value; applyTheme(); redraw(); saveS();
    });
  });

  function refreshUI() {
    var sel = $('themeSel'); sel.innerHTML = '';
    var d = document.createElement('option'); d.value = 'default'; d.textContent = 'MoonPad ' + (S.mode === 'light' ? 'Light' : 'Dark'); sel.appendChild(d);
    S.custom.forEach(function (t) { var o = document.createElement('option'); o.value = t.id; o.textContent = t.name; sel.appendChild(o); });
    sel.value = S.theme;
    var custom = S.theme !== 'default' && findCustom(S.theme);
    $('modeSw').checked = S.mode !== 'light';
    $('modeSw').disabled = !!custom;
    $('modeRow').className = 'row' + (custom ? ' dim' : '');
    $('modeRow').title = custom ? 'Dark/light applies to the default theme' : '';
    $('themeEd').className = custom ? 'show' : '';
    if (custom) {
      $('themeName').value = custom.name;
      KEYS.forEach(function (kv) { $('c_' + kv[0]).value = custom.vars[kv[0]]; });
    }
    $('bgOp').value = S.bgOpacity; $('bgOpVal').textContent = S.bgOpacity + '%';
    $('fontSel').value = S.font; $('fontCustom').value = S.customFont;
    $('fontSize').value = S.fontSize; $('fsVal').textContent = S.fontSize + 'px';
  }

  $('modeSw').addEventListener('change', function () {
    S.mode = $('modeSw').checked ? 'dark' : 'light'; applyTheme(); refreshUI(); redraw(); saveS();
  });
  $('themeSel').addEventListener('change', function () {
    S.theme = $('themeSel').value; applyTheme(); refreshUI(); redraw(); saveS();
  });
  $('newTheme').addEventListener('click', function () {
    var base = curVars(), vars = {};
    for (var k in base) vars[k] = base[k];
    var t = { id: 't' + Date.now(), name: 'Custom ' + (S.custom.length + 1), vars: vars };
    S.custom.push(t); S.theme = t.id; applyTheme(); refreshUI(); saveS();
  });
  $('themeName').addEventListener('input', function (e) {
    var t = findCustom(S.theme); if (!t) return;
    t.name = e.target.value || 'Untitled';
    var opt = $('themeSel').querySelector('option[value="' + t.id + '"]'); if (opt) opt.textContent = t.name;
    saveS();
  });
  $('delTheme').addEventListener('click', function () {
    var t = findCustom(S.theme); if (!t || !confirm('Delete theme "' + t.name + '"?')) return;
    S.custom = S.custom.filter(function (x) { return x.id !== t.id; });
    S.theme = 'default'; applyTheme(); refreshUI(); redraw(); saveS();
  });

  // background image (downscaled so the settings file stays small)
  $('bgBtn').addEventListener('click', function () { $('bgFile').click(); });
  $('bgFile').addEventListener('change', function (e) {
    var file = e.target.files && e.target.files[0]; if (!file) return;
    var r = new FileReader();
    r.onload = function () {
      var im = new Image();
      im.onload = function () {
        var sc = Math.min(1, 1920 / Math.max(im.width, im.height));
        var c = document.createElement('canvas');
        c.width = Math.round(im.width * sc); c.height = Math.round(im.height * sc);
        var g = c.getContext('2d'); g.fillStyle = curVars().bg; g.fillRect(0, 0, c.width, c.height);
        g.drawImage(im, 0, 0, c.width, c.height);
        S.bgImage = c.toDataURL('image/jpeg', 0.85); applyBg(); saveS();
      };
      im.src = r.result;
    };
    r.readAsDataURL(file);
    e.target.value = '';
  });
  $('bgClear').addEventListener('click', function () { S.bgImage = ''; applyBg(); saveS(); });
  $('bgOp').addEventListener('input', function (e) { S.bgOpacity = +e.target.value; $('bgOpVal').textContent = S.bgOpacity + '%'; applyBg(); saveS(); });

  $('fontSel').addEventListener('change', function (e) { S.font = e.target.value; applyFont(); saveS(); });
  $('fontCustom').addEventListener('input', function (e) { S.customFont = e.target.value; applyFont(); saveS(); });
  $('fontSize').addEventListener('input', function (e) { S.fontSize = +e.target.value; $('fsVal').textContent = S.fontSize + 'px'; applyFont(); saveS(); });

  // ================= board =================
  var els = {}, selId = null, zTop = 1, last = null;
  function byId(id) { for (var i = 0; i < nodes.length; i++) if (nodes[i].id === id) return nodes[i]; }
  function esc(s) { return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
  function toWorld(e) {
    var r = board.getBoundingClientRect();
    return { x: (e.clientX - r.left - v.x) / v.z, y: (e.clientY - r.top - v.y) / v.z };
  }
  function centerPos() {
    if (last) return { x: last.x, y: last.y };
    var r = board.getBoundingClientRect();
    return { x: (r.width / 2 - v.x) / v.z - 100, y: (r.height / 2 - v.y) / v.z - 60 };
  }
  function updateEmpty() { $('empty').style.display = nodes.length ? 'none' : 'block'; }

  function applyView() {
    world.style.transform = 'translate(' + v.x + 'px,' + v.y + 'px) scale(' + v.z + ')';
    var t = 'translate(' + v.x + ' ' + v.y + ') scale(' + v.z + ')';
    for (var gi = 0; gi < wgs.length; gi++) wgs[gi].setAttribute('transform', t);
    $('grid').style.backgroundPosition = v.x + 'px ' + v.y + 'px';
    $('grid').style.backgroundSize = (24 * v.z) + 'px ' + (24 * v.z) + 'px';
  }

  function curve(x1, y1, x2, y2) {
    var dx = Math.max(60, Math.abs(x2 - x1) * 0.5);
    return 'M' + x1 + ' ' + y1 + ' C' + (x1 + dx) + ' ' + y1 + ',' + (x2 - dx) + ' ' + y2 + ',' + x2 + ' ' + y2;
  }
  function redraw() {
    var inv = '', col = '';
    links.forEach(function (l, i) {
      var a = byId(l[0]), b = byId(l[1]);
      if (!a || !b) return;
      var d = curve(a.x + a.w, a.y + 15, b.x, b.y + 15);
      col += '<path class="hit" data-i="' + i + '" d="' + d + '"/>';
      if (l[2]) col += '<path class="w" data-v="' + i + '" style="stroke:' + l[2] + '" d="' + d + '"/>';
      else inv += '<path class="w inv" data-v="' + i + '" d="' + d + '"/>';
    });
    wlI.innerHTML = inv; wlC.innerHTML = col;
  }
  function hoverWire(e, on) {
    var i = e.target.getAttribute && e.target.getAttribute('data-i');
    if (i === null || i === undefined) return;
    var p = document.querySelector('path.w[data-v="' + i + '"]');
    if (p) p.style.strokeWidth = on ? '4' : '';
  }
  wl.addEventListener('mouseover', function (e) { hoverWire(e, true); });
  wl.addEventListener('mouseout', function (e) { hoverWire(e, false); });

  function place(n) {
    var el = els[n.id];
    el.style.left = n.x + 'px'; el.style.top = n.y + 'px';
    el.style.width = n.w + 'px'; el.style.height = n.h + 'px';
  }
  function select(id) {
    if (selId && els[selId]) els[selId].classList.remove('sel');
    selId = id;
    if (id && els[id]) { els[id].classList.add('sel'); els[id].style.zIndex = ++zTop; }
  }
  function paintHead(head, n) {
    head.style.background = n.color || '';
    head.style.color = n.color ? '#fff' : '';
  }
  function makeNode(n) {
    var el = document.createElement('div');
    el.className = 'node'; el.dataset.id = n.id;
    el.innerHTML = '<div class="head"><span class="dot"></span><span class="x">×</span></div>' +
      '<div class="body"></div><div class="pin in"></div><div class="pin out"></div><div class="grip"></div>';
    var body = el.querySelector('.body'), head = el.querySelector('.head');
    paintHead(head, n);
    if (n.type === 'text') {
      body.contentEditable = 'true';
      body.innerHTML = n.html || '';
      body.addEventListener('input', function () { n.html = body.innerHTML; save(); });
    } else if (n.type === 'video') {
      body.className = 'body vid';
      var vmsg = function (t) { body.className = 'body vid err'; body.innerHTML = ''; var m = document.createElement('div'); m.className = 'vmsg'; m.textContent = t; body.appendChild(m); };
      if (n.media && MEDIA && fs.existsSync(path.join(MEDIA, n.media))) {
        var vd = document.createElement('video');
        vd.controls = true; vd.loop = true; vd.preload = 'metadata'; vd.setAttribute('playsinline', '');
        vd.addEventListener('error', function () { vmsg('This video can\u2019t be played here. Try a WebM or H.264 MP4.'); });
        vd.src = mediaUrl(n.media);
        body.appendChild(vd);
      } else vmsg('Video file missing. Ask for a fresh export of this pad.');
    } else {
      body.className = 'body img';
      var im = document.createElement('img'); im.src = n.src; im.draggable = false;
      body.appendChild(im);
    }
    el.querySelector('.dot').addEventListener('click', function () {
      n.color = COLORS[(COLORS.indexOf(n.color) + 1) % COLORS.length];
      paintHead(head, n); redraw(); save();
    });
    el.querySelector('.x').addEventListener('click', function () { removeNode(n.id); });
    world.appendChild(el);
    els[n.id] = el;
    place(n);
    return el;
  }
  function addNode(p, pos) {
    var n = { id: st.nextId++, type: p.type, x: pos.x, y: pos.y, w: p.w || 240, h: p.h || 140,
      color: '', html: p.html || '', src: p.src || '', media: p.media || '' };
    nodes.push(n); makeNode(n); select(n.id); updateEmpty(); save();
    return n;
  }
  function removeNode(id) {
    var el = els[id]; if (el) el.parentNode.removeChild(el);
    delete els[id];
    nodes = nodes.filter(function (n) { return n.id !== id; });
    links = links.filter(function (l) { return l[0] !== id && l[1] !== id; });
    if (selId === id) selId = null;
    redraw(); updateEmpty(); save();
  }
  function addImage(file, pos) {
    var r = new FileReader();
    r.onload = function () {
      var im = new Image();
      im.onload = function () {
        var w = Math.min(360, im.naturalWidth || 360);
        var h = w * (im.naturalHeight / im.naturalWidth) + HEAD;
        addNode({ type: 'image', src: r.result, w: w, h: h }, pos);
      };
      im.src = r.result;
    };
    r.readAsDataURL(file);
  }

  function addImageData(dataUrl, pos) {
    var im = new Image();
    im.onload = function () {
      var w = Math.min(360, im.naturalWidth || 360);
      addNode({ type: 'image', src: dataUrl, w: w, h: w * (im.naturalHeight / im.naturalWidth) + HEAD }, pos);
    };
    im.src = dataUrl;
  }
  function placeVideo(name, pos) {
    var vv = document.createElement('video');
    vv.preload = 'metadata'; vv.muted = true;
    vv.onloadedmetadata = function () {
      var w = Math.min(420, vv.videoWidth || 420), ratio = vv.videoWidth ? vv.videoHeight / vv.videoWidth : 9 / 16;
      addNode({ type: 'video', media: name, w: w, h: w * ratio + HEAD }, pos);
      vv.removeAttribute('src');
    };
    vv.onerror = function () {
      setChip('');
      alert('MoonPad can\u2019t play that video in this panel (the codec isn\u2019t supported). Try a WebM, or an MP4 encoded as H.264.');
    };
    vv.src = mediaUrl(name);
  }
  function videoProblem() {
    if (!MEDIA || !crypto) return 'Videos need file storage, which isn\u2019t available here.';
    return '';
  }
  function addVideoPath(p, pos) {
    var ext = videoExt(p, ''), prob = videoProblem();
    if (prob) { alert(prob); return; }
    if (!ext) { alert('Unsupported video type. Use MP4, WebM, MOV, M4V or OGV.'); return; }
    try { if (fs.statSync(p).size > MAXVID) { alert('That video is over 200 MB. Trim or compress it first.'); return; } } catch (e) { alert('Could not read that file.'); return; }
    setChip('adding video…');
    storePath(p, ext, function (err, name) {
      if (err) { setChip(''); alert('Could not add that video.'); return; }
      placeVideo(name, pos);
    });
  }
  function addVideoFile(f, pos) {
    var ext = videoExt(f.name, f.type), prob = videoProblem();
    if (prob) { alert(prob); return; }
    if (!ext) { alert('Unsupported video type. Use MP4, WebM, MOV, M4V or OGV.'); return; }
    if (f.size > MAXVID) { alert('That video is over 200 MB. Trim or compress it first.'); return; }
    if (f.path && fs.existsSync(f.path)) { addVideoPath(f.path, pos); return; }
    setChip('adding video…');
    var r = new FileReader();
    r.onload = function () {
      try { placeVideo(storeBuffer(Buf.from(r.result), ext), pos); } catch (e) { setChip(''); alert('Could not add that video.'); }
    };
    r.readAsArrayBuffer(f);
  }
  var IMGEXT = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp', bmp: 'image/bmp' };
  function addMediaPath(p, pos) {
    var m = /\.([a-z0-9]+)$/i.exec(p), e = m ? m[1].toLowerCase() : '';
    if (IMGEXT[e]) {
      try { addImageData('data:' + IMGEXT[e] + ';base64,' + fs.readFileSync(p).toString('base64'), pos); } catch (x) { alert('Could not read that image.'); }
    } else addVideoPath(p, pos);
  }
  function doAddMedia() {
    var pos = centerPos();
    try {
      if (fs && window.cep && window.cep.fs && window.cep.fs.showOpenDialogEx) {
        var r = window.cep.fs.showOpenDialogEx(false, false, 'Add an image or video', '',
          ['png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp', 'mp4', 'm4v', 'mov', 'webm', 'ogv']);
        if (r && r.data && r.data.length) addMediaPath(r.data[0], pos);
        return;
      }
    } catch (e) { alert('Could not open that file.'); return; }
    var inp = $('mediaFile');
    inp.onchange = function () {
      var f = inp.files[0]; inp.value = ''; if (!f) return;
      if (f.type.indexOf('video') === 0) addVideoFile(f, pos); else if (f.type.indexOf('image') === 0) addImage(f, pos);
    };
    inp.click();
  }

  // ---------- mouse ----------
  var drag = null;

  world.addEventListener('mousedown', function (e) {
    var t = e.target, nodeEl = t.closest && t.closest('.node');
    if (!nodeEl) return;
    e.stopPropagation();
    var n = byId(+nodeEl.dataset.id);
    select(n.id);
    if (t.classList.contains('out')) {
      drag = { type: 'wire', from: n }; e.preventDefault();
    } else if (t.classList.contains('grip')) {
      drag = { type: 'resize', n: n, sx: e.clientX, sy: e.clientY, w0: n.w, h0: n.h }; e.preventDefault();
    } else if ((t.closest('.head') && !t.classList.contains('x') && !t.classList.contains('dot')) || t.closest('.body.img')) {
      drag = { type: 'move', n: n, sx: e.clientX, sy: e.clientY, x0: n.x, y0: n.y }; e.preventDefault();
    }
  });

  board.addEventListener('mousedown', function (e) {
    if (e.target !== board) return;
    select(null);
    drag = { type: 'pan', sx: e.clientX, sy: e.clientY, x0: v.x, y0: v.y };
    board.classList.add('panning');
    if (document.activeElement) document.activeElement.blur();
    e.preventDefault();
  });

  document.addEventListener('mousemove', function (e) {
    last = toWorld(e);
    if (!drag) return;
    if (drag.type === 'pan') {
      v.x = drag.x0 + (e.clientX - drag.sx); v.y = drag.y0 + (e.clientY - drag.sy); applyView();
    } else if (drag.type === 'move') {
      drag.n.x = drag.x0 + (e.clientX - drag.sx) / v.z; drag.n.y = drag.y0 + (e.clientY - drag.sy) / v.z;
      place(drag.n); redraw();
    } else if (drag.type === 'resize') {
      drag.n.w = Math.max(120, drag.w0 + (e.clientX - drag.sx) / v.z);
      drag.n.h = Math.max(60, drag.h0 + (e.clientY - drag.sy) / v.z);
      place(drag.n); redraw();
    } else if (drag.type === 'wire') {
      tmp.setAttribute('d', curve(drag.from.x + drag.from.w, drag.from.y + 15, last.x, last.y));
    }
  });

  document.addEventListener('mouseup', function (e) {
    if (!drag) return;
    var d = drag; drag = null;
    board.classList.remove('panning');
    if (d.type === 'wire') {
      tmp.setAttribute('d', '');
      var tgt = e.target.closest && e.target.closest('.node');
      if (tgt) {
        var b = byId(+tgt.dataset.id);
        var dup = b && links.some(function (l) { return l[0] === d.from.id && l[1] === b.id; });
        if (b && b !== d.from && !dup) links.push([d.from.id, b.id]);
      } else if (e.target === board) { // dropped on empty space -> new connected node
        var p = toWorld(e);
        var nn = addNode({ type: 'text' }, { x: p.x + 20, y: p.y - 15 });
        links.push([d.from.id, nn.id]);
        els[nn.id].querySelector('.body').focus();
      }
      redraw();
    }
    save();
  });

  board.addEventListener('wheel', function (e) {
    e.preventDefault();
    var r = board.getBoundingClientRect(), mx = e.clientX - r.left, my = e.clientY - r.top;
    var nz = Math.min(2.5, Math.max(0.2, v.z * (e.deltaY < 0 ? 1.1 : 1 / 1.1)));
    v.x = mx - (mx - v.x) * (nz / v.z); v.y = my - (my - v.y) * (nz / v.z); v.z = nz;
    applyView(); save();
  });

  board.addEventListener('dblclick', function (e) {
    if (e.target !== board) return;
    var p = toWorld(e);
    var n = addNode({ type: 'text' }, { x: p.x, y: p.y });
    els[n.id].querySelector('.body').focus();
  });

  wl.addEventListener('dblclick', function (e) {
    var i = e.target.getAttribute && e.target.getAttribute('data-i');
    if (i !== null && i !== undefined) { links.splice(+i, 1); redraw(); save(); }
  });
  wl.addEventListener('mousedown', function (e) { e.stopPropagation(); });

  // ---------- paste / drop / keys ----------
  function inField() {
    var ae = document.activeElement;
    return !!ae && (ae.tagName === 'INPUT' || ae.tagName === 'TEXTAREA' || ae.tagName === 'SELECT');
  }
  document.addEventListener('paste', function (e) {
    if (inField()) return;
    var items = (e.clipboardData && e.clipboardData.items) || [], got = false;
    for (var i = 0; i < items.length; i++) {
      if (items[i].type.indexOf('image') === 0) {
        var pos = centerPos(); pos.x += got ? 30 : 0; pos.y += got ? 30 : 0;
        addImage(items[i].getAsFile(), pos); got = true;
      } else if (items[i].type.indexOf('video') === 0 && items[i].getAsFile()) {
        var vpos = centerPos(); vpos.x += got ? 30 : 0; vpos.y += got ? 30 : 0;
        addVideoFile(items[i].getAsFile(), vpos); got = true;
      }
    }
    if (got) { e.preventDefault(); return; }
    var t = e.clipboardData && e.clipboardData.getData('text/plain');
    var ae = document.activeElement;
    if (ae && ae.isContentEditable) {
      if (t) { e.preventDefault(); document.execCommand('insertText', false, t); }
      return;
    }
    if (t) { e.preventDefault(); addNode({ type: 'text', html: esc(t).replace(/\n/g, '<br>') }, centerPos()); }
  });

  board.addEventListener('dragover', function (e) { e.preventDefault(); });
  board.addEventListener('drop', function (e) {
    var files = e.dataTransfer && e.dataTransfer.files;
    if (!files || !files.length) return;
    e.preventDefault();
    var p = toWorld(e);
    for (var i = 0; i < files.length; i++) {
      var f = files[i];
      if (/\.mnpad$/i.test(f.name)) { readDropped(f); break; }
      if (f.type.indexOf('image') === 0) addImage(f, { x: p.x + i * 30, y: p.y + i * 30 });
      else if (f.type.indexOf('video') === 0 || videoExt(f.name, '')) addVideoFile(f, { x: p.x + i * 30, y: p.y + i * 30 });
    }
  });
  function readDropped(f) {
    var r = new FileReader();
    r.onload = function () { openFromText(r.result, f.name, null); };
    r.readAsText(f);
  }

  document.addEventListener('keydown', function (e) {
    var ae = document.activeElement;
    if (e.key === 'Escape') { closeMenu(); closeWMenu(); openSettings(false); return; }
    if ((e.key === 'Delete' || e.key === 'Backspace') && selId && !inField() && !(ae && ae.isContentEditable)) {
      removeNode(selId);
    }
  });

  $('addBtn').addEventListener('click', function () {
    var n = addNode({ type: 'text' }, centerPos());
    els[n.id].querySelector('.body').focus();
  });
  $('resetBtn').addEventListener('click', function () { v.x = 40; v.y = 40; v.z = 1; applyView(); save(); });

  // ================= init =================
  applyTheme(); applyBg(); applyFont(); refreshUI();
  // ================= Wire color menu (right-click a link) =================
  var wmenu = $('wmenu'), wIdx = -1;
  function closeWMenu() { wmenu.className = ''; wIdx = -1; }
  function setLinkColor(col) {
    var l = links[wIdx]; if (!l) return;
    l.length = 2; if (col) l.push(col);
    closeWMenu(); redraw(); save();
  }
  function openWMenu(i, x, y) {
    var l = links[i]; if (!l) return;
    wIdx = i; wmenu.innerHTML = '';
    var lab = document.createElement('div'); lab.className = 'mlabel'; lab.textContent = 'Link color'; wmenu.appendChild(lab);
    var grid = document.createElement('div'); grid.className = 'swgrid';
    WIRE_COLORS.forEach(function (c) {
      var b = document.createElement('div'); b.className = 'swb' + (l[2] === c[1] ? ' on' : '');
      b.style.background = c[1]; b.title = c[0];
      b.addEventListener('click', function () { setLinkColor(c[1]); });
      grid.appendChild(b);
    });
    wmenu.appendChild(grid);
    var sep = document.createElement('div'); sep.className = 'msep'; wmenu.appendChild(sep);
    var d = document.createElement('div'); d.className = 'mi'; d.textContent = 'Default (inverted)';
    d.addEventListener('click', function () { setLinkColor(''); }); wmenu.appendChild(d);
    var del = document.createElement('div'); del.className = 'mi'; del.textContent = 'Delete link';
    del.addEventListener('click', function () { links.splice(wIdx, 1); closeWMenu(); redraw(); save(); });
    wmenu.appendChild(del);
    wmenu.className = 'open';
    wmenu.style.left = Math.max(4, Math.min(x, window.innerWidth - wmenu.offsetWidth - 6)) + 'px';
    wmenu.style.top = Math.max(4, Math.min(y, window.innerHeight - wmenu.offsetHeight - 6)) + 'px';
  }
  wl.addEventListener('contextmenu', function (e) {
    var i = e.target.getAttribute && e.target.getAttribute('data-i');
    if (i === null || i === undefined) return;
    e.preventDefault(); e.stopPropagation();
    closeMenu(); openWMenu(+i, e.clientX, e.clientY);
  });
  document.addEventListener('mousedown', function (e) {
    if (wmenu.className === 'open' && !wmenu.contains(e.target)) closeWMenu();
  }, true);
  board.addEventListener('wheel', closeWMenu);

  // ================= File menu =================
  var menu = $('menu');
  function closeMenu() { menu.className = ''; }
  function mItem(label, fn, bold) {
    var d = document.createElement('div'); d.className = 'mi'; d.textContent = label;
    if (bold) d.style.fontWeight = '600';
    d.addEventListener('click', function () { closeMenu(); fn(); });
    menu.appendChild(d);
  }
  function mSep(label) {
    var s = document.createElement('div'); s.className = 'msep'; menu.appendChild(s);
    if (label) { var l = document.createElement('div'); l.className = 'mlabel'; l.textContent = label; menu.appendChild(l); }
  }
  function buildMenu() {
    menu.innerHTML = '';
    mItem('Add image or video…', doAddMedia);
    mItem('Open pad…', doOpen);
    mItem('Export a copy…', doExport);
    mItem('Import into this pad…', doImport);
    mItem('Show in folder', function () { reveal(curFile || PADS, !!curFile); });
    if (PADS) {
      var list = [];
      try {
        fs.readdirSync(PADS).forEach(function (n) {
          if (/\.mnpad$/i.test(n)) list.push({ n: n, t: fs.statSync(path.join(PADS, n)).mtime.getTime() });
        });
      } catch (e) {}
      list.sort(function (a, b) { return b.t - a.t; });
      if (list.length) mSep('Your pads');
      list.slice(0, 8).forEach(function (x) {
        var full = path.join(PADS, x.n), cur = curFile && full === curFile;
        mItem((cur ? '✓ ' : '') + x.n.replace(/\.mnpad$/i, ''), function () {
          if (cur) return;
          try { openFromText(fs.readFileSync(full, 'utf8'), x.n, full); } catch (e) { alert('Could not read that file.'); }
        }, cur);
      });
    }
  }
  $('fileBtn').addEventListener('click', function () {
    if (menu.className === 'open') { closeMenu(); return; }
    buildMenu();
    menu.className = 'open';
    menu.style.left = Math.max(4, Math.min($('fileBtn').getBoundingClientRect().left, window.innerWidth - menu.offsetWidth - 6)) + 'px';
  });
  document.addEventListener('mousedown', function (e) {
    if (menu.className === 'open' && !menu.contains(e.target) && !$('fileBtn').contains(e.target)) closeMenu();
  });

  function reveal(p, isFile) {
    if (!p) return;
    try {
      var cp = require('child_process');
      if (process.platform === 'win32') {
        cp.spawn('explorer', [isFile ? '/select,"' + p + '"' : '"' + p + '"'], { detached: true, windowsVerbatimArguments: true }).unref();
      } else if (process.platform === 'darwin') {
        cp.spawn('open', isFile ? ['-R', p] : [p]).unref();
      } else cp.spawn('xdg-open', [isFile ? path.dirname(p) : p]).unref();
    } catch (e) {}
  }

  function pickFile(cb) {
    try {
      if (fs && window.cep && window.cep.fs && window.cep.fs.showOpenDialogEx) {
        var r = window.cep.fs.showOpenDialogEx(false, false, 'Select a MoonPad file (.mnpad)', PADS || '', ['mnpad']);
        if (r && r.data && r.data.length) { var p = r.data[0]; cb(fs.readFileSync(p, 'utf8'), path.basename(p), p); }
        return;
      }
    } catch (e) { alert('Could not read that file.'); return; }
    var inp = $('padFile');
    inp.onchange = function () {
      var f = inp.files[0]; inp.value = ''; if (!f) return;
      var rd2 = new FileReader(); rd2.onload = function () { cb(rd2.result, f.name, null); }; rd2.readAsText(f);
    };
    inp.click();
  }
  function doOpen() { pickFile(openFromText); }
  function doImport() { pickFile(function (text) { mergeFromText(text); }); }

  // Open = switch this AE project to that pad. Files from outside the MoonPad folder are copied in.
  function openFromText(text, name, srcPath) {
    var pad = parsePad(text);
    if (!pad) { alert('That is not a valid MoonPad (.mnpad) file.'); return; }
    flushSave();
    var inFolder = false, dest = null;
    if (fs && PADS) {
      if (srcPath && sameDir(path.dirname(srcPath), PADS)) { dest = srcPath; inFolder = true; }
      else dest = path.join(PADS, uniqueName(name));
      map.projects[keyOf(curProject)] = { file: path.basename(dest), project: curProject || '' };
      saveMap();
    }
    curFile = dest; padCreated = pad.created;
    loadPad(pad);
    if (inFolder) setChip('opened'); else saveNow();
  }

  // Import = merge another pad's nodes into the current one, placed to the right of what's there.
  function mergeFromText(text) {
    var pad = parsePad(text);
    if (!pad) { alert('That is not a valid MoonPad (.mnpad) file.'); return; }
    var px = Infinity, py = Infinity, maxX = 0, minY = Infinity;
    pad.nodes.forEach(function (n) { px = Math.min(px, n.x); py = Math.min(py, n.y); });
    nodes.forEach(function (n) { maxX = Math.max(maxX, n.x + n.w); minY = Math.min(minY, n.y); });
    var ox = (nodes.length ? maxX + 80 : 40) - px, oy = (nodes.length ? minY : 40) - py, idMap = {};
    pad.nodes.forEach(function (n) {
      idMap[n.id] = st.nextId; n.id = st.nextId++; n.x += ox; n.y += oy;
      nodes.push(n); makeNode(n);
    });
    pad.links.forEach(function (l) {
      var nl = [idMap[l[0]], idMap[l[1]]]; if (l[2]) nl.push(l[2]); links.push(nl);
    });
    redraw(); updateEmpty(); save();
  }

  // exported files are self-contained: videos are packed inside as data URLs
  function exportObject() {
    var o = padObject(), total = 0, ok = true;
    o.nodes = o.nodes.map(function (n) {
      var c = {}; for (var k in n) c[k] = n[k]; return c;
    });
    o.nodes.forEach(function (n) {
      if (n.type === 'video' && n.media && MEDIA) { try { total += fs.statSync(path.join(MEDIA, n.media)).size; } catch (e) {} }
    });
    if (total > EXPORT_CAP) {
      ok = confirm('This pad has ' + Math.round(total / 1048576) + ' MB of video, which is too big to bundle into one file.\n\nExport without the videos?');
      if (!ok) return null;
    }
    o.nodes.forEach(function (n) {
      if (n.type !== 'video') return;
      var keep = ok && total <= EXPORT_CAP && n.media && MEDIA;
      if (keep) {
        try {
          var ext = n.media.split('.').pop();
          n.src = 'data:' + VMIME[ext] + ';base64,' + fs.readFileSync(path.join(MEDIA, n.media)).toString('base64');
        } catch (e) { n.src = ''; }
      }
      n.media = '';
    });
    return o;
  }
  function doExport() {
    flushSave();
    var eo = exportObject(); if (!eo) return;
    var s = JSON.stringify(eo), def = padBase() + '.mnpad';
    try {
      if (fs && window.cep && window.cep.fs && window.cep.fs.showSaveDialogEx) {
        var r = window.cep.fs.showSaveDialogEx('Export MoonPad file', PADS || '', ['mnpad'], def);
        if (r && r.data) {
          var p = String(r.data); if (!/\.mnpad$/i.test(p)) p += '.mnpad';
          writeAtomic(p, s); setChip('exported');
        }
        return;
      }
    } catch (e) { alert('Export failed: ' + e.message); return; }
    var a = document.createElement('a');
    a.href = 'data:application/json;charset=utf-8,' + encodeURIComponent(s); a.download = def;
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
  }

  $('padPath').textContent = PADS || '(file storage unavailable)';
  $('openFolder').addEventListener('click', function () { reveal(PADS, false); });

  // ================= start =================
  var entered = false, polling = false;
  function start(p) { if (entered) return; entered = true; enterProject(p); }
  getProject(start);
  setTimeout(function () { start(''); }, 3000); // safety net if AE doesn't answer
  setInterval(function () {
    if (!entered || polling) return;
    polling = true;
    getProject(function (p) { polling = false; if (p !== curProject) enterProject(p); });
    setTimeout(function () { polling = false; }, 1500);
  }, 2000);
  window.addEventListener('beforeunload', flushSave);
})();
